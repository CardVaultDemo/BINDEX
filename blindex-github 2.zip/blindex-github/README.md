# Blindex

Application web de collection de cartes Pokémon (démo) — créée par De0xys.

Une seule page statique : `index.html`, sans dépendance ni étape de build.

## Démo
Après activation de GitHub Pages : `https://<votre-pseudo>.github.io/<nom-du-depot>/`

## Important
- Les cartes, extensions, numéros et prix de la base intégrée sont **fictifs** (démo).
- Les comptes sont des comptes de démonstration stockés dans le navigateur (non sécurisés).
- Le scanner est **simulé** : aucune IA n'analyse réellement l'image.
- Points d'extension dans le code : `DB` (stockage), `Auth` (comptes), `Catalog` (cartes), `Recognizer` (scan), `Services.price` (prix).

## Version démo verrouillée
Cette version utilise le stockage de session : chaque visiteur démarre avec des cartes d'exemple, peut tout essayer, et ses modifications disparaissent à la fermeture de l'onglet. Rien n'est partagé entre visiteurs, et seul le propriétaire du dépôt peut modifier la page.
